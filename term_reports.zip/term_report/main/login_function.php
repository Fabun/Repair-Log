<?php
include("db_conn.php");
$db = new DB();
$conn = $db->connection();

$username = $_POST['username'];
$password = $_POST['password'];


$sql = "SELECT * FROM signup_page WHERE username='$username' AND password= '$password' ";
$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result)==1) 
{
	session_start();
	$_SESSION['signup_page'] = 'true';
	$_SESSION['username'] = $username;
	header('location: ../index.php');

}else{
	header('location: login.php');
}
mysqli_close($conn);
?>