<?php
session_start();
if (!$_SESSION['signup_page']) {
	header('location: ../index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Fault Form</title>
	<link rel="stylesheet" type="text/css" href="../css/style111.css">
	<link href="https://fonts.googleapis.com/css?family=Arimo" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../css/stylee.css">
</head>
<body style="margin: 0;
	padding: 0;
	background: url(../img/hand.jpg);
	background-size: cover;
    font-family: sans-serif;">
	<nav>
		<div class="topnav">
			<a href="../index.php">Home<i class="fa fa-home" aria-hidden="true"></i></a>

			<a href="../main/logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
		</div>
	</nav>
	
<div class="form-wrap">
	<form form action="../main/repair_log.php" method="POST"> 
		<h1>Add Faults</h1>
		<input  type="text" name="terminal_serial" placeholder="Terminal Serial"  />
		   	<input  type="text" name="terminal_id" placeholder="Terminal Id"/>
		   	<input  type="text" name="terminal_type" placeholder="Terminal Type"/>
		   	<input  type="text" name="fault_descriptions" placeholder="Fault Descriptions"/>
		   	<select name=" Fault Categories" class="select"  required >
				<option>PRINTER</option>
				<option>SCREEN</option>
				<option>MAIN-BOARD</option>
				<option>CARD-READER</option>
				<option>KEYPAD</option>
				<option>FUNCTION KEY</option>
				<option>ATM KEY</option>
				<option>CASE</option>
				<option>SAM BOARD/IO BOARD</option>
				<option>POWER-BOARD</option>
				<option>PRINTER-COVER</option>
				<option>ERRORS</option>
			</select>

			<select name="banks" class="select" required>
				<option>ACCESS BANK</option>
				<option>DIAMOND BANK</option>
				<option>ECOBANK</option>
				<option>FCMB</option>
				<option>FET</option>
				<option>FIDELITY BANK</option>
				<option>FIRST BANK</option>
				<option>GTBANK</option>
				<option>KEYSTONE BANK</option>
				<option>SKYE BANK</option>
				<option>STANBIC BANK</option>
				<option>STERLING BANK</option>
				<option>TEASY MOBILE</option>
				<option>UBA</option>
				<option>UNION BANK</option>
				<option>UNITY BANK</option>
				<option>WEMA BANK</option>
				<option>ZENITH BANK</option>
			</select>

			<input type="date" name="date_received"  ><br>
			<input type="text" name="status"  placeholder="status" required>
			<input    type="submit"  name="submit" value="Submit">
	</form>
	<form  action="../main/upload.php"  method="POST" enctype="multipart/form-data">
			<input type="file" name="file" >
			<input type="submit" name="upload" value="Upload" style="background-color: black; color: red; hover:grey;">
</form>
</div>

</body>
</html>

