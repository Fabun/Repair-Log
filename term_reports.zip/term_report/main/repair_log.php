<!-- FAULT FORM  -->
<?php
//database connection
include ("db_conn.php");
class Repair_log
{

	// a function that adds faulty terminals to database
	function Add()
	{     
		//database connection
		$db = new DB();
		$conn = $db->connection();	

		$terminal_serial = $_POST["terminal_serial"];
		$terminal_id = $_POST["terminal_id"];
		$terminal_type = $_POST["terminal_type"];
		$fault_descriptions = $_POST["fault_descriptions"];
		$fault_categories = $_POST["fault_categories"];
		$date_received = $_POST["date_received"];
		$date_delivered = $_POST["date_delivered"];
		$banks = $_POST["banks"];
		$status = $_POST["status"];

//the query simply updates the database(repair_log) of faulty terminals
		$query = "INSERT INTO repair_log(terminal_serial, terminal_id, terminal_type, fault_descriptions, fault_categories, date_received, date_delivered , banks, status)
		VALUES('$terminal_serial', '$terminal_id', '$terminal_type', '$fault_descriptions', '$fault_categories',  '$date_received','$date_delivered', '$banks', '$status')
		ON DUPLICATE KEY UPDATE terminal_serial = '$terminal_serial', terminal_id = '$terminal_id', terminal_type = '$terminal_type', fault_descriptions = '$fault_descriptions', fault_categories = '$fault_categories',   date_received = '$date_received' , date_delivered = '$date_delivered', banks = '$banks' ,status = '$status'  ";

//after updation a redirection is done to the fault form
		if ($conn->query($query) === TRUE) {
			header("Location: fault_form.php");
		} else {
			echo "Error: " . $query . "<br>" . $conn->error;
		}

		$conn->close();

	}
}

$repair_log = new Repair_log();
$repair_log->Add();



?>