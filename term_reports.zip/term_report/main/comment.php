<?php
//Database Connection
include 'db_conn.php';
include 'comment_function.php';

session_start();
if (!$_SESSION['signup_page']) {
	header('location:../index.php');
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.O1 Transitional//EN* *http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>Fault Log</title>
	<link rel="stylesheet" type="text/css" href="../css/stylee.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
</head>

<!DOCTYPE html>
<html>
<head>
	<title>comment box</title>
	<link rel="stylesheet" type="text/css" href="../css/style5.css">
</head><br><br>
<nav>
	<div class="topnav">
				<a href="../index.php">Home<i class="fa fa-home" aria-hidden="true"></i></a>

				<a href="../main/fault_form.php"><i class="fa fa-plus" aria-hidden="true"></i>
				Add Faults</a>
				<a href="../main/logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>
				Logout</a>
				<div class="search-container">
					<form action="index.php" method="POST">
						<input type="text" placeholder="Search.."   name="search"  autocomplete="on" required>
						<button type="submit"><i class="fa fa-search" aria-hidden="true"></i>
						</button>
					</form>
				</div>
			</div>
	</nav>
<body class="wonder">
	<div>
		<table id='customers' style='font-family:Comic Sans MS, cursive;'>
			<tr>
				<th>Terminal Serial</th>
				<th>Terminal ID</th>
				<th>Terminal Type</th>
				<th>Date Received</th>
				<th>Date Delivered</th>
				<th>Banks</th>
				<th>Fault Descriptions</th>
				<th>status</th>
			</tr>
			<?php prevComments(); ?>
		</table>

		<?php 
         getcomments();
		echo "<div class='container' style='font-family:Comic Sans MS', cursive';>
		<form  method='POST' action='".setComments()."'>
		<div class='row'>
		<div class='col-25'>
		<label for='subject'>Comment</label>
		</div>
		<div class='col-75'>
		<input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
		<textarea name='message' id='subject' style='height:200px'></textarea>
		<div class='row'>
		<input type='submit' name='commentSubmit'  style='background-color:black; color:white; border-radius:5px;' value='Comment'>
		</div>
		</form>
		</div>"; 


		?>
	</div>
</body>
</html>
