<?php
// a function that fetches data from signup_page ,and adds comment to the database. 
function setComments(){
//database connection
	$db = new DB();
	$conn = $db->connection();

	if(isset($_POST['commentSubmit'])){
		$date = $_POST['date'];
		$comment = $_POST['message'];
		$user = $_SESSION['username'];
		$tid = $_GET['id'];


		$query = "SELECT id FROM signup_page WHERE username = '$user' ";
		$result = mysqli_query($conn, $query);
		$uid = mysqli_fetch_assoc($result);
		$userid = $uid['id'];

		$sql = "INSERT INTO comment VALUES('Default','$userid','$tid','$date','$comment')";
		$call = mysqli_query($conn, $sql);
	}
}

//a function that fetches data from comment, signup_page and displays the date,username,message from database.
function getcomments(){
	$db = new DB();
	$conn = $db->connection();

	$tid = htmlspecialchars($_GET['id']);
	$tid = trim($_GET['id']);

	$query = "SELECT * FROM comment WHERE tid = '$tid'";
	$query = mysqli_query($conn,$query);
	echo "<br><br><br><br>";
	while($result = mysqli_fetch_assoc($query)){
		$uid = $result['uid'];
		$userid = "SELECT username FROM signup_page WHERE id ='$uid'";
		$userid = mysqli_query($conn,$userid);
		while($user = mysqli_fetch_assoc($userid)){
			echo "<div class='comment-box'><p>";
			echo $result['date'] ."<br>";
			echo"<li>" .$user['username'] ."<br>";
			echo nl2br($result['message']) ."<br>";
			echo "</p></div>";  
		}
	}
}

// a function that fetches data from repair_log and displays all data from repair_log.
function prevComments(){

	$db = new DB();
	$conn = $db->connection();

	$tid = htmlspecialchars($_GET['id']);
	$tid = trim($_GET['id']);

	$query = "SELECT * FROM repair_log WHERE id = '$tid'";
	$result = mysqli_query($conn,$query);
	while($row = mysqli_fetch_assoc($result)){
		if($row['date_delivered'] == "0000-00-00 00:00:00"){
			$row['date_delivered'] = "Not Delivered";
		}
		
		echo "<tr>
		<td>" .$row['terminal_serial']."</td>
		<td>" .$row['terminal_id']."</td>
		<td>" .$row['terminal_type']."</td>
		<td>" .$row['date_received']."</td> 
		<td>" .$row['date_delivered']."</td>
		<td>" .$row['banks']. "</td>
		<td>" .$row['fault_categories']."</td>
		<td>" .$row['status']. "</td>
		</tr>";

	}
}

?>

