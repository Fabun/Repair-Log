	
<!DOCTYPE html>
<html>
<head>
	<title>Signup Page</title>
	<link rel="stylesheet" type="text/css" href="../css/stylee.css">
	<link rel="stylesheet" type="text/css" href="../css/styl1.css">
</head>
<body>
	<nav>
		<div class="topnav">
			
			<div class="search-container">
				<a href="login.php">Login</a>
			</div>
		</div>
	</nav>

<div class="login-box2">
		
		<h1>Signup Here</h1>
		<form action="signup_function.php" method="POST">
		<p>Username</p>	
		   <input type="text" name="username" required>
		   <p>Password</p>
		   <input type="password" name="password"  required>
		   <p>Confirm Password</p>
		   <input type="password" name="confirm_password" required>
		   <input type="submit" name="submit"  value="Signup">
		  
		</form>
	</div>
</body>
</html>