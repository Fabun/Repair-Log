<?session_start();
if (!$_SESSION['signup_page']) {
	header('location:main/index.php');
}?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.O1 Transitional//EN* *http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>Fault Log</title>
	<link rel="stylesheet" type="text/css" href="stylee.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
	
</head>
<div class="container">
	<body class="body">
		<nav>
			<div class="topnav">
				<a href="index.php">Home<i class="fa fa-home" aria-hidden="true"></i></a>

				<a href="fault_form.php"><i class="fa fa-plus" aria-hidden="true"></i>
				Add Faults</a>
				<a href="login.php"><i class="fa fa-sign-out" aria-hidden="true"></i>
				Logout</a>
				<div class="search-container">
					<form action="index.php" method="POST">
						<input type="text" placeholder="Search.."   name="search"  autocomplete="on"        required>
						<button type="submit"><i class="fa fa-search" aria-hidden="true"></i>
						</button>
					</form>
				</div>
			</div>
		</nav>
<br><br><br>
<?php
if ($_POST){

$terminal_serial = $_POST['terminal_serial'];
$terminal_id = $_POST['terminal_id'];
$handle = fopen("comments.html","a");
fwrite ($handle,"<b>" . $terminal_serial . "</b></br>" . $terminal_id . "</br>");
fclose ($handle);}


?>

<html>
<body>

<form action="comment_function.php" method="POST">
Content: <textarea rows ="10" cols ="30" name="comments"></textarea></br>
<input type = "submit" value = "post!"></br>
</form>

<?php include "comments.html"; ?>
</body>
</html>