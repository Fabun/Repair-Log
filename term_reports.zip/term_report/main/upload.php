<?php
//database connection
include("../main/db_conn.php");

$db = new DB();
$conn = $db->connection();
//if upload button is clicked a query is executed that inserts data to the database.
if (isset($_POST["upload"]))
{
	$fileName = $_FILES['file']['name'];
	$fileTmpName = $_FILES['file']['tmp_name'];

	$fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
//a variable that accept csv format for a file uploaded.
	$allowedType = array('csv');
	if (!in_array($fileExtension, $allowedType)) {
		header('location: fault_form.php');
	}
	else {
		$handle = fopen($fileTmpName,'r');
		while (($mydata = fgetcsv($handle,',')) !== FALSE)  {
			$terminal_serial = $mydata[0];
			$terminal_id = $mydata[1];
			$terminal_type = $mydata[2];
			$date_received = $mydata[3];
			$date_delivered = $mydata[4];
			$banks = $mydata[5];
			$fault_descriptions = $mydata[6];
			$fault_categories = $mydata[7];
			$status = $mydata[8];
          //import query
			$query = "INSERT INTO repair_log (terminal_serial,terminal_id,terminal_type,date_received,date_delivered,banks,fault_descriptions,fault_categories,status) VALUES ('".$terminal_serial."','".$terminal_id."','".$terminal_type."','".$date_received."','".$date_delivered."','".$banks."','".$fault_descriptions."','".$fault_categories."','".$status."')";

			$run = mysqli_query($conn, $query);


		}
		if (!$run) {
			die("error in uploading file".mysqli_error());
		}else{
			header('location: fault_form.php');
		}
	}
}


mysqli_close($conn);
?>