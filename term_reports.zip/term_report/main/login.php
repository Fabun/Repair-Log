<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="../css/stylee.css">
	<link rel="stylesheet" type="text/css" href="../css/styl1.css">
	<body>
		<nav>
			<div class="topnav">
				<img src="../img/itex.jpg" style="width: 120px; height: 60px;">
				<div class="search-container">
					<a href="../main/signup.php">Signup</a>
				</div>
			</div>
		</nav>
	
		<div class="login-box">
			<img src="../img/avatar.png" class="avatar">
			<p class="error"></p><p class="success"></p>
			<h1>Login Here</h1>
			<p class="error"><?php $error ?></p>
			<form method="POST" action="login_function.php">
				<p>Username</p>
				<input type="text" name="username" required>
				<p>Password</p>
				<input type="Password" name="password" required>
				<input type="submit" name="submit"  value="Login">
              </form>
          </div>
	</body>
	</html>
	



	
	
