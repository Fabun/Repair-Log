<?php

include ("db_conn.php");
$db = new DB();
$conn = $db->connection();

$username = $_POST['username'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

$sql = "INSERT INTO signup_page (username, password, confirm_password) 
VALUES ('$username', '$password', '$confirm_password ')";
$result = $conn->query($sql);


header("location:login.php");

mysqli_close($conn);
?>