<?php

session_start();
if (!$_SESSION['signup_page']) {
	header('location:main/index.php');
}
?>
<link rel="stylesheet" type="text/css" href="../css/stylee.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<div class="container">
	<body class="body" style="background: url(../img/hmm.jpg);">
		<nav>
			<div class="topnav">
				<a href="../index.php">Home<i class="fa fa-home" aria-hidden="true"></i></a>

				<a href="../main/fault_form.php"><i class="fa fa-plus" aria-hidden="true"></i>
				Add Faults</a>
				<a href="../main/logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>
				Logout</a>
				<div class="search-container">
					<form action="index.php" method="POST">
						<input type="text" placeholder="Search.."   name="search"  autocomplete="on"  required>
						<button type="submit"><i class="fa fa-search" aria-hidden="true"></i>
						</button>
					</form>
				</div>
			</div>
		</nav>
		<br><br><br>

		<?php
        //database connection
		include("db_conn.php");
		$db = new DB();
		$conn = $db->connection();
         
         //dispalys the table structure of data displayed
		echo "<table id='customers' style='font-family:Comic Sans MS', cursive'>
		<tr>
		<th>S/N</th>
		<th>Terminal Serial</th>
		<th>Terminal ID</th>
		<th>Terminal Type</th>
		<th>Date Recieved</th>
		<th>Date Delivered</th>
		<th>Banks</th>
		<th>Fault Descriptions</th>
		<th>Fault Categories</th>
		<th>Status</th>
		</tr>";

		//if terminal serial($tis) is clicked a query is executed that displays a reference
		if(!empty($_GET['tis'])){
			$tis = htmlspecialchars($_GET['tis']);
			$tis = trim($_GET['tis']);
			$i = 1;
           
           //reference query
			$query = "SELECT * FROM repair_log  WHERE terminal_serial = '$tis' ORDER BY terminal_serial DESC";
			$val = mysqli_query($conn,$query);
			//reference data displayed
			while($row = mysqli_fetch_array($val)){
				echo "<tr>
				<td>" .$i. "</td>
				<td>" .$row['terminal_serial']. "</a></td>
				<td>" .$row['terminal_id']. "</td>
				<td>" .$row['terminal_type']. "</td>
				<td>" .$row['date_received']. "</td>
				<td>" .$row['date_delivered']. "</td>
				<td>" .$row['banks']. "</td>
				<td>" .$row['id'].$row['fault_descriptions']."</td>
				<td><a href='../main/comment.php?id=".$row['id']."' style='text-decoration: none;'>" .$row['fault_categories']. "</td>
				<td>" .$row['status']. "</td>
				</tr>"; $i++;
			}
			"</table>";
		}
		
		?>
		

		