 <?php

 class DB
 {


 	private $servername = "localhost";
 	private $username = "root";
 	private $password = "";
 	private $dbname = "repair_log";

 	public function connection()
 	{

 		$conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);

 		if (!$conn) 
 		{
 			echo "Failed";
 			die("Connection failed: " . mysqli_connect_error());
 		}
 		echo "";

 		return $conn;

 	}
 }
 ?> 