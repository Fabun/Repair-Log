<?php

require_once('db_conn.php');

class Comment {

	function comment_table(){

		$db = new DB();
		$conn = $db->connection();


		$query = 'CREATE TABLE comment (
		id				INT(11)		NOT NULL AUTO_INCREMENT,
		terminal_serial			VARCHAR(100)     NOT NULL ,
		terminal_id            VARCHAR(100)         NOT NULL,
		comment			VARCHAR(100)		NOT NULL,
		
		PRIMARY KEY (id)
		)
		ENGINE=MyISAM';
	// mysql_query($query, $conn) or die(mysql_error($conn));
		$conn->query($query) or die($conn->error);
	}
}
$create = new Comment ;
$create->comment_table();
