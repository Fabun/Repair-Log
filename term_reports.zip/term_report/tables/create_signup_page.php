<?php

require_once('../main/db_conn.php');

class Build {

	function signup_page_display(){

		$db = new DB();
		$conn = $db->connection();


		$query = 'CREATE TABLE signup_page (
		id				INT(11)		NOT NULL AUTO_INCREMENT,
		username			VARCHAR(100) 	NOT NULL ,
		password        VARCHAR(100) NOT NULL,
		confirm_password    VARCHAR(100) NOT NULL,


		PRIMARY KEY (id)
		)
		ENGINE=MyISAM';
	// mysql_query($query, $conn) or die(mysql_error($conn));
		$conn->query($query) or die($conn->error);
	}
}
$create = new Build;
$create-> signup_page_display();