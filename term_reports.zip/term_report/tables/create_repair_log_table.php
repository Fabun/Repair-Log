<?php

require_once('../main/db_conn.php');

class Create {

	function repair_log_table(){

      $db = new DB();
      $conn = $db->connection();


		$query = 'CREATE TABLE repair_log (
		id				INT(11)		NOT NULL AUTO_INCREMENT,
		terminal_serial			VARCHAR(100)     NOT NULL ,
		terminal_id            VARCHAR(100)         NOT NULL,
		terminal_type			VARCHAR(100)		NOT NULL,
		fault_descriptions      VARCHAR(100)       NOT NULL,
		fault_categories         VARCHAR(100)      NOT NULL,
		banks                     VARCHAR(100)      NOT NULL,
		date_received            datetime           NOT NULL,
		date_delivered            datetime           NOT NULL,
		status               VARCHAR(100)          NOT NULL,


		PRIMARY KEY (id)
		)
		ENGINE=MyISAM';
	// mysql_query($query, $conn) or die(mysql_error($conn));
		$conn->query($query) or die($conn->error);
	}
}
$create = new Create;
$create-> repair_log_table();
