<?php

require_once('../main/db_conn.php');

class Create {

	function comment_table(){

      $db = new DB();
      $conn = $db->connection();


		$query = 'CREATE TABLE comment (
		id				INT(11)		NOT NULL AUTO_INCREMENT,
		uid       INT(11)       NOT NULL,
		tid        INT(11)       NOT NULL,
		date	datetime 		NOT NULL,
		message      VARCHAR(100)       NOT NULL,
		FOREIGN KEY(uid) REFERENCES signup_page(id),
		FOREIGN KEY(tid) REFERENCES repair_log(id),


		PRIMARY KEY (id)
		)
		ENGINE=MyISAM';
	// mysql_query($query, $conn) or die(mysql_error($conn));
		$conn->query($query) or die($conn->error);
	}
}
$create = new Create;
$create-> comment_table();
